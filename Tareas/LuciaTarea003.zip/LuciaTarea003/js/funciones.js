'use strict'

//Iniciamos una variable estableciendo que en ella ira texto
let fact = "";

//de esta variable saldra el window prompt para el usuario
fact = prompt("Introduce un numero entero positivo");

//variable para la operacion del factorial
let n = fact;
for (let i = fact - 1; i >= 1; i--) {
    fact = fact * i;
}

//Nos muestra el resultado(no se como se hace para que se vea el proceso de la multiplicacion)
alert(n + "! =" + fact);